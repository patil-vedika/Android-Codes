package com.example.experiment4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ShowActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper = new DatabaseHelper(this);


    TextView rollNoText;
    TextView nameText;
    TextView subjectText;
    TextView genderText;
    TextView agreeText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_activity);

        Intent intent = getIntent();
        String rollNo = intent.getStringExtra("rollNo");

        rollNoText = findViewById(R.id.show_roll);
        nameText = findViewById(R.id.show_name);
        subjectText = findViewById(R.id.show_subject);
        genderText = findViewById(R.id.show_gender);
        agreeText = findViewById(R.id.show_agree);
        ArrayList<Object[]> list = databaseHelper.readData(rollNo);
        rollNoText.setText("Roll No: " + list.get(0)[0]);
        nameText.setText("Name: " + list.get(0)[1]);
        subjectText.setText("Subject: " + list.get(0)[2]);
        genderText.setText("Gender: " + list.get(0)[3]);
        agreeText.setText("Agreed to store data: " + (list.get(0)[4].equals("1") ? "Yes": "No"));
    }
}
