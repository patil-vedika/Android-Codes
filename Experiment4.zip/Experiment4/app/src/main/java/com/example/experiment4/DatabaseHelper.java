package com.example.experiment4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String databaseName = "student.db";

    public DatabaseHelper(Context context) {
        super(context, databaseName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table students(rollno TEXT primary key, name TEXT, subject TEXT, gender TEXT, agree INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists students");
    }

    public Boolean insertData(String rollno, String name, String subject, String gender, Boolean agree) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("rollno", rollno);
        contentValues.put("name", name);
        contentValues.put("subject", subject);
        contentValues.put("gender", gender);
        contentValues.put("agree", (agree == true ? 1 : 0));
        Long result = db.insert("students", null, contentValues);
        return result == -1 ? false : true;
    }

    public ArrayList readData(String rollno) {
        ArrayList<Object[]> list = new ArrayList();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from students where rollno = ?", new String[]{rollno});
        if(cursor != null && cursor.moveToFirst()) {
            do{
                Object[] rowData = new Object[cursor.getColumnCount()];
                for(int i=0; i<rowData.length; i++) {
                    rowData[i] = cursor.getString((i));
                }
                list.add(rowData);
            }while(cursor.moveToNext());
        }
        return list;
    }
}
