package com.example.experiment4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper databaseHelper;

    EditText rollNoText;
    EditText nameText;
    Spinner subjectSpinner;
    RadioGroup radioGroup;
    CheckBox checkBox;
    Button showActivity;

    String rollNo = "", name = "", subject = "", gender = "";
    Boolean agree = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rollNoText = findViewById(R.id.rollNo);
        nameText = findViewById(R.id.name);
        subjectSpinner = findViewById(R.id.subjectSpinner);
        radioGroup = findViewById(R.id.radioGroup);
        checkBox = findViewById(R.id.checkbox);
        showActivity = findViewById(R.id.showActivity);

        databaseHelper = new DatabaseHelper(this);

        ArrayList<String> subjects = new ArrayList<>();
        subjects.add("FOC");
        subjects.add("AD");
        subjects.add("DM");
        subjects.add("I&E");
        subjects.add("DBM");
        ArrayAdapter<String> subjectAdapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, subjects);
        subjectSpinner.setAdapter(subjectAdapter);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = findViewById(checkedId);
                gender = radioButton.getText().toString();
            }
        });

        subjectSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                subject = subjects.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                subject = subjects.get(0);
            }
        });

        showActivity.setOnClickListener(new View.OnClickListener() {

            TextView errorMessage = findViewById(R.id.errorMessage);

            @Override
            public void onClick(View v) {
                rollNo = rollNoText.getText().toString();
                name = nameText.getText().toString();
                agree = checkBox.isChecked();

                if(rollNo == "" || name == "" || agree == false || subject == "" || gender == "") {
                    errorMessage.setText("All fields are mandatory!");
                }
                else {
                    errorMessage.setText("");
                    databaseHelper.insertData(rollNo, name, subject, gender, agree);
                    Intent intent = new Intent(getApplicationContext(), ShowActivity.class);
                    intent.putExtra("rollNo", rollNo);
                    startActivity(intent);
                }

            }
        });


    }
}